# InterviewReady — payments backend scaffold

This is a real Stripe integration scaffold: authentication, a database-backed
subscription model, Checkout Sessions, a verified webhook handler, a billing
portal, and a server-side entitlements check. It was written by hand in an
environment with no network access, so **none of it has been installed, run,
or tested against a live Stripe account yet.** Treat it as a correct starting
point, not a verified one — run it locally and fix anything that surfaces
before shipping.

## What this does and doesn't include

Included: everything needed to accept a real subscription payment and gate a
feature behind it (see the checklist in the previous report — this covers
every missing item there).

Not included: the actual InterviewReady product UI (`InterviewReady.jsx`)
hasn't been ported into this Next.js project yet. This scaffold is the
payments/auth layer; wiring the existing landing page, onboarding, dashboard,
and job analysis screens into these routes is a separate follow-up.

## 1. Install dependencies

```bash
cd interviewready-backend
npm install
```

## 2. Set up the database

Get a Postgres connection string — a free instance from Supabase, Neon, or
Railway all work fine for development.

```bash
cp .env.example .env
# edit .env and set DATABASE_URL

npx prisma migrate dev --name init
```

## 3. Set up Stripe (test mode)

1. Create a Stripe account at https://dashboard.stripe.com if you don't have one.
2. Make sure you're in **Test mode** (toggle top-right of the dashboard).
3. Go to **Product catalog > Add product**. Create two products:
   - "InterviewReady Plus" — recurring price, $15/month
   - "InterviewReady Premium" — recurring price, $29/month
4. Copy each price's ID (starts with `price_...`, not the product ID which
   starts with `prod_...`) into `.env` as `STRIPE_PRICE_PLUS` /
   `STRIPE_PRICE_PREMIUM`.
5. Go to **Developers > API keys**, copy the test secret and publishable
   keys into `.env`.
6. Generate `NEXTAUTH_SECRET`: `openssl rand -base64 32`.

## 4. Forward webhooks locally

Stripe can't reach `localhost` directly, so use the Stripe CLI to forward
events to your machine while developing:

```bash
stripe login
npm run stripe:listen
```

This prints a `whsec_...` value — put it in `.env` as `STRIPE_WEBHOOK_SECRET`.
Keep this command running in a separate terminal whenever you're testing
checkout locally.

## 5. Run it

```bash
npm run dev
```

Sign up a user via `POST /api/auth/signup`, sign in, then trigger checkout
via the `/api/checkout` route (see `components/PricingButton.example.tsx`
for the client call). Use Stripe's test card `4242 4242 4242 4242`, any
future expiry, any CVC.

Confirm the whole loop actually works before moving on:
- Checkout completes and redirects to `success_url`
- The webhook terminal shows `checkout.session.completed` received
- The user's `Subscription` row in the database now shows `plan: "plus"` (or `"premium"`) and `status: "active"`
- `GET /api/me` reflects the new plan
- Canceling the subscription from the Billing Portal (`/api/billing-portal`) eventually flips the row back to free via `customer.subscription.deleted`

## 6. Go live

1. In the Stripe Dashboard, switch **out of Test mode**.
2. Recreate the same two products/prices in live mode (test-mode and
   live-mode data are entirely separate) — you'll get new `price_...` IDs.
3. Get live API keys from **Developers > API keys** and update your
   **production** environment variables (`STRIPE_SECRET_KEY`,
   `STRIPE_PUBLISHABLE_KEY`, `STRIPE_PRICE_PLUS`, `STRIPE_PRICE_PREMIUM`).
   Never put live keys in `.env` files that get committed anywhere.
4. In **Developers > Webhooks**, add a live endpoint pointing to
   `https://yourdomain.com/api/webhooks/stripe`, subscribed to at least:
   `checkout.session.completed`, `customer.subscription.created`,
   `customer.subscription.updated`, `customer.subscription.deleted`.
   Copy its signing secret into the production `STRIPE_WEBHOOK_SECRET`.
5. Point `DATABASE_URL` at your production Postgres instance and run
   `npx prisma migrate deploy` against it (not `migrate dev`).
6. Set `APP_URL` and `NEXTAUTH_URL` to your real production domain.
7. Do one real end-to-end test purchase with a real card before announcing
   pricing publicly, and check it in the Stripe Dashboard's live event log.

## Where things intentionally stop here

- No email delivery (password reset, receipts beyond Stripe's own) is wired up.
- No rate limiting on `/api/auth/signup` or `/api/checkout`.
- No admin view of subscriptions — you'd use the Stripe Dashboard for that initially.
- The example gated route (`app/api/mock-interview/start/route.ts`) shows the
  *shape* of a real enforcement check but references product data models
  (job preps, mock questions) that don't exist yet in this schema.
