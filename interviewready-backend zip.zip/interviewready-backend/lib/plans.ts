// Single source of truth for what each plan is called, which Stripe
// Price it maps to, and what it unlocks. Both the checkout route and
// the webhook handler import from here so they can never drift apart.

export type PlanId = "free" | "plus" | "premium";

export const PLAN_PRICE_IDS: Record<Exclude<PlanId, "free">, string> = {
  plus: process.env.STRIPE_PRICE_PLUS ?? "",
  premium: process.env.STRIPE_PRICE_PREMIUM ?? "",
};

// Reverse lookup used by the webhook handler: given a Stripe Price ID
// that came back on a subscription object, which of our plans is it?
export function planFromPriceId(priceId: string | null | undefined): PlanId {
  if (priceId && priceId === PLAN_PRICE_IDS.plus) return "plus";
  if (priceId && priceId === PLAN_PRICE_IDS.premium) return "premium";
  return "free";
}

export const PLAN_LIMITS: Record<PlanId, { activeJobPreps: number; mockQuestionsPerPrep: number; detailedFeedback: boolean }> = {
  free: { activeJobPreps: 1, mockQuestionsPerPrep: 10, detailedFeedback: false },
  plus: { activeJobPreps: Infinity, mockQuestionsPerPrep: Infinity, detailedFeedback: true },
  premium: { activeJobPreps: Infinity, mockQuestionsPerPrep: Infinity, detailedFeedback: true },
};
