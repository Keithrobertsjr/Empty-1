import { getServerSession } from "next-auth";
import { authOptions } from "./auth";
import { db } from "./db";
import { PLAN_LIMITS, PlanId } from "./plans";

/**
 * Loads the signed-in user's subscription record and returns their plan
 * plus its limits. This is the ONLY place that should decide whether a
 * request is allowed to use a paid feature — never trust a plan name
 * sent from the client.
 *
 * Returns null if there is no signed-in user.
 */
export async function getCurrentEntitlements() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) return null;

  const subscription = await db.subscription.findUnique({ where: { userId } });
  const plan = (subscription?.plan as PlanId) ?? "free";

  // Treat a subscription that's past_due/canceled/incomplete as free-tier
  // access, even if a "plan" string is still sitting on the row — status
  // is what actually gates access, not the plan name alone.
  const activeStatuses = new Set(["active", "trialing"]);
  const effectivePlan: PlanId = subscription && activeStatuses.has(subscription.status) ? plan : "free";

  return {
    userId,
    plan: effectivePlan,
    status: subscription?.status ?? "active",
    limits: PLAN_LIMITS[effectivePlan],
  };
}

/**
 * Example guard for use inside a route handler:
 *
 *   const entitlements = await getCurrentEntitlements();
 *   if (!entitlements) return unauthorized();
 *   if (entitlements.limits.mockQuestionsPerPrep <= usedThisPrep) {
 *     return NextResponse.json({ error: "upgrade_required" }, { status: 402 });
 *   }
 */
