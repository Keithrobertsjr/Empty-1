import { NextResponse } from "next/server";
import { getCurrentEntitlements } from "@/lib/entitlements";

// Informational only — lets the client show "You're on the Plus plan"
// or gray out a button. It must NEVER be trusted as the enforcement
// point for a paid feature; see app/api/mock-interview/start/route.ts
// for what real enforcement looks like.
export async function GET() {
  const entitlements = await getCurrentEntitlements();
  if (!entitlements) return NextResponse.json({ signedIn: false });

  return NextResponse.json({
    signedIn: true,
    plan: entitlements.plan,
    status: entitlements.status,
    limits: entitlements.limits,
  });
}
