import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";

export async function POST(req: Request) {
  const { email, password, name } = await req.json();

  if (!email || !password || password.length < 8) {
    return NextResponse.json(
      { error: "Email and a password of at least 8 characters are required." },
      { status: 400 }
    );
  }

  const existing = await db.user.findUnique({ where: { email: email.toLowerCase() } });
  if (existing) {
    return NextResponse.json({ error: "An account with that email already exists." }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(password, 12);

  // Every user gets a Subscription row immediately, defaulted to "free".
  // This means the rest of the app never has to special-case "no
  // subscription row yet" — there's always exactly one to read.
  const user = await db.user.create({
    data: {
      email: email.toLowerCase(),
      passwordHash,
      name,
      subscription: { create: { plan: "free", status: "active" } },
    },
  });

  return NextResponse.json({ id: user.id, email: user.email });
}
