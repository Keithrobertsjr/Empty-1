import { NextResponse } from "next/server";
import { getCurrentEntitlements } from "@/lib/entitlements";
import { db } from "@/lib/db";

/**
 * Worked example: this is what a REAL feature gate looks like on the
 * server, as opposed to just hiding a button in the UI. Wire the
 * Dashboard's "Start mock interview" action to a route like this one
 * once mock interviews are backed by real data.
 */
export async function POST(req: Request) {
  const entitlements = await getCurrentEntitlements();
  if (!entitlements) {
    return NextResponse.json({ error: "Sign in to start a mock interview." }, { status: 401 });
  }

  const { jobPrepId } = await req.json();

  // PSEUDO-CODE: this app doesn't have a JobPrep / MockInterviewQuestion
  // model yet (that's the real product data, not the payments layer).
  // The point being illustrated is the shape of the check, not this
  // exact query — once those models exist, replace this with a real
  // `db.mockInterviewQuestion.count({ where: { jobPrepId } })`.
  const questionsUsed = 0; // <- replace with a real usage count

  if (questionsUsed >= entitlements.limits.mockQuestionsPerPrep) {
    return NextResponse.json(
      {
        error: "upgrade_required",
        message: "You've used all the mock questions included in your plan for this prep.",
      },
      { status: 402 } // 402 Payment Required — the semantically correct status for this
    );
  }

  // ... create and return the next mock interview question here.
  return NextResponse.json({ ok: true });
}
