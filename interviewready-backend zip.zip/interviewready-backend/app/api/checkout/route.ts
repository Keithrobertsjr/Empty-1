import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { stripe } from "@/lib/stripe";
import { PLAN_PRICE_IDS } from "@/lib/plans";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) {
    return NextResponse.json({ error: "Sign in before starting checkout." }, { status: 401 });
  }

  const { plan } = (await req.json()) as { plan?: "plus" | "premium" };
  const priceId = plan ? PLAN_PRICE_IDS[plan] : undefined;
  if (!priceId) {
    return NextResponse.json({ error: "Unknown or unconfigured plan." }, { status: 400 });
  }

  const user = await db.user.findUniqueOrThrow({ where: { id: userId } });

  // Reuse an existing Stripe customer for this user rather than creating
  // a new one every time they open checkout.
  let customerId = user.stripeCustomerId;
  if (!customerId) {
    const customer = await stripe.customers.create({
      email: user.email,
      metadata: { userId: user.id },
    });
    customerId = customer.id;
    await db.user.update({ where: { id: user.id }, data: { stripeCustomerId: customerId } });
  }

  const checkoutSession = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer: customerId,
    line_items: [{ price: priceId, quantity: 1 }],
    success_url: `${process.env.APP_URL}/dashboard?checkout=success`,
    cancel_url: `${process.env.APP_URL}/pricing?checkout=canceled`,
    // Belt-and-suspenders: the webhook can look the user up via the
    // customer ID, but stamping the userId in metadata too makes the
    // webhook handler simpler and more robust to edge cases.
    subscription_data: { metadata: { userId: user.id } },
    metadata: { userId: user.id },
  });

  return NextResponse.json({ url: checkoutSession.url });
}
