import { NextResponse } from "next/server";
import Stripe from "stripe";
import { stripe } from "@/lib/stripe";
import { db } from "@/lib/db";
import { planFromPriceId } from "@/lib/plans";

// Stripe needs the Node runtime (not the Edge runtime) so the SDK's
// crypto-based signature verification works.
export const runtime = "nodejs";

// This webhook is the ONLY thing allowed to write subscription status.
// The client never gets to say "I'm on the Plus plan now" — only a
// verified event from Stripe can change that in the database.
export async function POST(req: Request) {
  const rawBody = await req.text();
  const signature = req.headers.get("stripe-signature");

  if (!signature || !process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({ error: "Missing signature or webhook secret." }, { status: 400 });
  }

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("Stripe webhook signature verification failed:", err);
    return NextResponse.json({ error: "Invalid signature." }, { status: 400 });
  }

  switch (event.type) {
    case "checkout.session.completed": {
      const checkoutSession = event.data.object as Stripe.Checkout.Session;
      const userId = checkoutSession.metadata?.userId;
      const stripeSubscriptionId = checkoutSession.subscription as string | null;
      if (userId && stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(stripeSubscriptionId);
        await upsertSubscriptionFromStripe(userId, subscription);
      }
      break;
    }

    // Covers upgrades, downgrades, renewals, payment failures (past_due),
    // and Stripe-initiated cancellations at period end.
    case "customer.subscription.updated":
    case "customer.subscription.created": {
      const subscription = event.data.object as Stripe.Subscription;
      const userId = await resolveUserId(subscription);
      if (userId) await upsertSubscriptionFromStripe(userId, subscription);
      break;
    }

    case "customer.subscription.deleted": {
      const subscription = event.data.object as Stripe.Subscription;
      const userId = await resolveUserId(subscription);
      if (userId) {
        await db.subscription.update({
          where: { userId },
          data: { plan: "free", status: "canceled", stripeSubscriptionId: null, stripePriceId: null },
        });
      }
      break;
    }

    default:
      // Unhandled event types are fine to ignore — Stripe sends many
      // more events than this app currently needs to react to.
      break;
  }

  return NextResponse.json({ received: true });
}

async function resolveUserId(subscription: Stripe.Subscription): Promise<string | undefined> {
  if (subscription.metadata?.userId) return subscription.metadata.userId;
  const customerId = subscription.customer as string;
  const user = await db.user.findUnique({ where: { stripeCustomerId: customerId } });
  return user?.id;
}

async function upsertSubscriptionFromStripe(userId: string, subscription: Stripe.Subscription) {
  const priceId = subscription.items.data[0]?.price.id ?? null;
  const plan = planFromPriceId(priceId);

  await db.subscription.upsert({
    where: { userId },
    create: {
      userId,
      plan,
      status: subscription.status,
      stripeSubscriptionId: subscription.id,
      stripePriceId: priceId,
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
    },
    update: {
      plan,
      status: subscription.status,
      stripeSubscriptionId: subscription.id,
      stripePriceId: priceId,
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
    },
  });
}
