"use client";

import { useState } from "react";

/**
 * Drop-in replacement for the pricing card CTA in InterviewReady.jsx.
 * Today every card's button calls the same onStart() -> /onboarding
 * handler. Paid plans should call this instead; Free can keep the
 * existing behavior.
 *
 * Usage in the pricing section:
 *   p.highlight
 *     ? <PricingButton plan="plus" label={p.cta} />
 *     : <SecondaryButton onClick={onStart}>{p.cta}</SecondaryButton>
 */
export function PricingButton({ plan, label }: { plan: "plus" | "premium"; label: string }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleClick() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan }),
      });
      const data = await res.json();

      if (!res.ok) {
        // Most common case: user isn't signed in yet.
        if (res.status === 401) {
          window.location.href = `/login?next=/pricing`;
          return;
        }
        setError(data.error ?? "Something went wrong starting checkout.");
        return;
      }

      window.location.href = data.url; // redirect to Stripe-hosted Checkout
    } catch {
      setError("Couldn't reach the server. Try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <button onClick={handleClick} disabled={loading} className="w-full">
        {loading ? "Redirecting to checkout…" : label}
      </button>
      {error && <p className="text-xs text-red-600 mt-2">{error}</p>}
    </div>
  );
}
